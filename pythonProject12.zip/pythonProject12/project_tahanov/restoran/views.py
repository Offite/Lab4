from django.shortcuts import render, get_object_or_404, redirect
from .models import Restoran
from .forms import RestoranForm

def restoran_list(request):
    restorans = Restoran.objects.all()
    return render(request, 'restorans/restoran_list.html', {'restorans': restorans})

def add_restoran(request, pk):
    restoran = get_object_or_404(RestoranForm, pk=pk)
    if request.method == 'POST':
        form = RestoranForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('restoran_list')
    else:
        form = RestoranForm()(instance=restoran)
    return render(request, 'restorans/restoran_form.html', {'form': form})

def edit_restoran(request, pk):
    dish = get_object_or_404(Restoran, pk=pk)
    if request.method == 'POST':
        form = RestoranForm(request.POST, instance=Restoran)
        if form.is_valid():
            form.save()
            return redirect('restoran_list')
    else:
        form = RestoranForm(instance=Restoran)
    return render(request, 'restorans/restoran_form.html', {'form': form})
def delete_restoran(request, pk):
    restoran = get_object_or_404(Restoran, pk=pk)
    restoran.delete()
    return redirect('restoran_list')
