from django import forms
from .models import restoran

class RestoranForm(forms.ModelForm):
    class Meta:
        model = restoran
        fields = ['title', 'category', 'price', 'ingredients']
