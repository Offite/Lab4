from django.urls import path
from .views import restoran_list, add_restoran, edit_restoran, delete_restoran

urlpatterns = [
    path('', restoran_list(), name='restoran_list'),
    path('add/', add_restoran(), name='add_restoran'),
    path('edit/<int:pk>/', edit_restoran, name='edit_restoran'),
    path('delete/<int:pk>/', delete_restoran(), name='delete_restoran'),
]